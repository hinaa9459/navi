/*
 * tests/check.js — 案内文の自動検査（修正のたびに必ず実行する）
 *
 *   node tests/check.js            … 検査を実行（問題があれば内容を表示して失敗で終わる）
 *   node tests/check.js --update   … 案内文の一覧（snapshot.txt）を今の結果で更新する
 *
 * 検査の内容
 *   1. 実ルート（tests/fixtures の全国18本）の全案内文を、ルール（下の RULES）で検査
 *   2. 曲がり方の種類 × 方向 × 出口名・方面・交差点名・道路名・路線番号の有無 × 車/徒歩 の
 *      全組み合わせ（総当たり）を同じルールで検査
 *   3. 実ルートを最初から最後まで模擬走行し、案内漏れ・到着しない等がないか検査
 *   4. 案内文の一覧を snapshot.txt と比べ、変わった文をすべて表示（意図した変更か人が確認する）
 */
'use strict';
var fs = require('fs'), path = require('path');
var N = require('../navcore.js'), R = require('../routing.js');

var DIR = path.join(__dirname, 'fixtures');
var SNAP = path.join(__dirname, 'snapshot.txt');
var problems = [];
function fail(where, rule, text) { problems.push(where + '\n    [' + rule + '] ' + text); }

// ---------- ルール ----------
// 英字の単語は、ここにあるもの（JCT、IC、E1A など）以外は出してはいけない
var ALLOWED_LATIN = /^(JCT|IC|SA|PA|ETC|SIC|[ECK]\d+[A-Z]?)$/;
function sideOf(text) {
  if (/目的地/.test(text)) return 'dest';
  if (/Uターン|引き返す/.test(text)) return 'u';
  if (/右/.test(text)) return 'R';
  if (/左/.test(text)) return 'L';
  if (/直進|道なり|合流|ロータリー/.test(text)) return 'S';
  return '?';
}
var RULES = [
  ['壊れた文字', function (r) { var all = r.say + r.action + r.sign + r.sub; return /undefined|null|NaN|\[object/.test(all) && '「' + all + '」'; }],
  ['重複した言葉', function (r) {
    var all = [r.say, r.action, r.sign, r.sub].join('|');
    var m = all.match(/JCT出口|出口出口|入口入口|方面方面|、、|ですです|ICIC|出口、[^、]*出口です|方向方向/);
    return m && '「' + m[0] + '」 in 「' + r.say + '」';
  }],
  ['読み上げは「です／ます」で終わる', function (r) { return !/(です|ます)$/.test(r.say) && '「' + r.say + '」'; }],
  ['読み上げが長すぎる（45字まで）', function (r) { return r.say.length > 45 && r.say.length + '字「' + r.say + '」'; }],
  // 英語の名前（「Ise Expressway」「the crosswalk」など）が出ていないか。JR渋谷駅・Uターンのような日本語の中の英字はよい
  ['英語が混ざっている', function (r) {
    var all = [r.say, r.sign, r.sub];
    for (var i = 0; i < all.length; i++) {
      var m = all[i].match(/[A-Za-z]+(?:[ .'\-]+[A-Za-z]+)+/) ||                    // 英語の複数語
              (/^[\x00-\x7F]+$/.test(all[i]) && /[a-z]{2}/.test(all[i]) ? [all[i]] : null); // 全部英語の名前
      if (m && !ALLOWED_LATIN.test(m[0])) return '「' + m[0] + '」 in 「' + all.join(' / ') + '」';
    }
    return false;
  }],
  ['案内板の枠に出した名前は、読み上げにも入る', function (r) { return r.sign && r.say.indexOf(r.sign) < 0 && '枠「' + r.sign + '」読み上げ「' + r.say + '」'; }],
  ['案内板と読み上げの向きが同じ', function (r) {
    var a = sideOf(r.action), b = sideOf(r.say);
    return a !== '?' && b !== '?' && a !== b && '案内板「' + r.action + '」読み上げ「' + r.say + '」';
  }],
  ['出口名・JCT名があれば読み上げる', function (r, st) {
    var t = st.maneuver.type;
    return st.exitName && !st.foot && (t === 'off ramp' || t === 'fork') && r.say.indexOf(String(st.exitName).replace(/出口$/, '')) < 0 && '出口名「' + st.exitName + '」読み上げ「' + r.say + '」';
  }],
  ['交差点名があれば読み上げる', function (r, st) {
    var t = st.maneuver.type;
    var ramp = st.foot && (t === 'on ramp' || t === 'off ramp') ? 'fork' : t;
    var applies = /^(turn|continue|end of road|fork|off ramp|on ramp|new name)$/.test(ramp) && !(st.exitName && !st.foot && (ramp === 'off ramp' || ramp === 'fork'));
    return st.junction && applies && r.say.indexOf(st.junction) < 0 && '交差点「' + st.junction + '」読み上げ「' + r.say + '」';
  }],
  ['徒歩で「右折・左折」や高速の入口・出口の言い方を使わない', function (r, st) { return st.foot && /右折|左折|方向、(入口|出口)です/.test(r.say) && '「' + r.say + '」'; }],
  ['枠と小さい文字が同じ', function (r) { return r.sign && r.sign === r.sub && '「' + r.sign + '」'; }],
  ['同じ地名を2回言わない', function (r) {
    var parts = r.say.replace(/です$/, '').split('、').map(function (p) { return p.replace(/(IC出口|出口|方面|IC|JCT)$/, ''); }).filter(Boolean);
    for (var i = 0; i < parts.length; i++) for (var j = i + 1; j < parts.length; j++) if (parts[i] === parts[j] && !/方向/.test(parts[i])) return '「' + r.say + '」';
    return r.sign && r.sub && r.sub.replace(/方面$/, '') === r.sign.replace(/(IC出口|出口|IC|JCT)$/, '') && '枠「' + r.sign + '」と小さい文字「' + r.sub + '」';
  }],
  ['JCTを出口と呼ばない', function (r) { return /JCT出口/.test(r.say + r.sign) && '「' + r.say + '」'; }],
];
function checkStep(where, st) {
  var r = N.describe(st);
  RULES.forEach(function (rule) {
    var bad = rule[1](r, st);
    if (bad) fail(where, rule[0], bad);
  });
  return r;
}

// ---------- 1. 実ルート ----------
var files = fs.readdirSync(DIR).filter(function (f) { return /\.json$/.test(f); }).sort();
var snapshot = [], routes = [];
var VALHALLA_KNOWN = {};
files.forEach(function (f) {
  var raw = JSON.parse(fs.readFileSync(path.join(DIR, f), 'utf8'));
  var foot = /_foot_/.test(f), res;
  if (raw.trip) {
    raw.trip.legs[0].maneuvers.forEach(function (m) { VALHALLA_KNOWN[m.type] = (VALHALLA_KNOWN[m.type] || 0) + 1; });
    res = R.fromValhalla(raw, { profile: foot ? 'foot' : 'car' });
  } else {
    res = raw;
    res.meta = { provider: 'osrm', profile: foot ? 'foot' : 'car' };
  }
  var rt = N.prepareRoute(res);
  routes.push({ name: f, rt: rt });
  snapshot.push('## ' + f);
  rt.guides.forEach(function (g, i) {
    var where = f + ' #' + i + ' (' + (g.at / 1000).toFixed(1) + 'km ' + g.maneuver.type + ' ' + (g.maneuver.modifier || '') + ')';
    var r = checkStep(where, g);
    snapshot.push(r.say + '\t｜' + r.action + (r.sign ? '［' + r.sign + '］' : '') + (r.sub ? ' ' + r.sub : ''));
  });
});

// Valhallaの曲がり方の番号がすべて変換表にあるか（知らない番号は「直進」扱いになり案内が抜ける）
var MAPPED = Object.keys(R.VALHALLA_TYPE).map(Number);
Object.keys(VALHALLA_KNOWN).forEach(function (t) {
  if (MAPPED.indexOf(+t) < 0) fail('Valhalla type ' + t + '（' + VALHALLA_KNOWN[t] + '回）', '変換表にない曲がり方', 'routing.js の VALHALLA_TYPE に追加が必要');
});

// ---------- 2. 総当たり ----------
var TYPES = ['turn', 'continue', 'new name', 'end of road', 'fork', 'off ramp', 'on ramp', 'merge',
  'roundabout', 'rotary', 'roundabout turn', 'exit roundabout', 'arrive', 'facility'];
var MODS = ['left', 'right', 'slight left', 'slight right', 'sharp left', 'sharp right', 'straight', 'uturn'];
var EXITS = [null, '台場', '伊勢西IC', '四日市JCT', '大月出口', '甲府昭和インター'];
var DESTS = [null, '名古屋,新静岡', '伊勢市街,伊勢神宮(外宮)', '大月出口', '河口湖IC', '首都高速'];
var JNS = [null, '甲府駅前', '伊勢西IC'];
var NAMES = [null, '中央自動車道', '平和通り'];
var REFS = [null, '20', 'E1A'];
var count = 0;
TYPES.forEach(function (t) { MODS.forEach(function (mod) { EXITS.forEach(function (ex) { DESTS.forEach(function (de) {
  JNS.forEach(function (jn) { NAMES.forEach(function (nm) { REFS.forEach(function (rf) { [false, true].forEach(function (foot) {
    var st = { maneuver: { type: t, modifier: mod, exit: 2 }, name: nm || '' };
    if (t === 'facility') st.facility = ['steps', 'escalator', 'elevator', 'building enter', 'building exit', 'ferry enter', 'ferry exit'][count % 7];
    if (ex) st.exitName = ex; if (de) st.destinations = de; if (jn) st.junction = jn; if (rf) st.ref = rf; if (foot) st.foot = true;
    count++;
    checkStep('総当たり ' + JSON.stringify({ type: t, mod: mod, exit: ex, dest: de, jn: jn, name: nm, ref: rf, foot: foot }), st);
  }); }); }); });
}); }); }); });

// ---------- 3. 模擬走行 ----------
routes.forEach(function (o) {
  var rt = o.rt, foot = rt.foot, along = 0, t = 0, spoken = {}, arrived = false;
  var v = foot ? 1.3 : 14;
  while (t < 40000) {
    t++; along += v;
    var u = N.update(rt, N.pointAt(rt, along).p, v);
    if (u.speak) spoken[u.guideIndex] = (spoken[u.guideIndex] || '') + u.speak + ' / ';
    if (u.arrived) { arrived = true; break; }
  }
  if (!arrived) fail(o.name, '模擬走行で到着しない', '最後まで走っても到着判定にならない');
  // 曲がり角はすべて、少なくとも1回は読み上げられる（すぐ先の曲がり角は「その先」でまとめて伝える場合あり）
  rt.guides.forEach(function (g, i) {
    if (g.maneuver.type === 'arrive' || g.at < 30) return;
    var said = spoken[i] || '';
    var prev = spoken[i - 1] || '';
    var chained = prev.indexOf('その先、' + N.describe(g).say) >= 0;
    if (said.indexOf(N.describe(g).say) < 0 && !chained) fail(o.name + ' #' + i + ' ' + (g.at / 1000).toFixed(1) + 'km', '案内漏れ', '「' + N.describe(g).say + '」が一度も読み上げられない');
  });
});

// ---------- 3b. 地図の向き（進行方向が上）：止まっていても、ルートのこれから進む向きになる ----------
routes.forEach(function (o) {
  var rt = o.rt;
  [0, rt.total * 0.25, rt.total * 0.5, rt.total * 0.75].forEach(function (along) {
    var ahead = rt.foot ? 15 : 30;                // アプリと同じ見る距離
    var h = N.headingAhead(rt, along, ahead);
    // 期待値：この先の区間でルートが実際に向かう方向のどれかと30°以内、
    // または曲がり角の手前で「今の向き」と「曲がった後の向き」の間（古い向き・逆向きを検出する）
    var hs = [], best = 180;
    for (var d = 0; d <= ahead; d += 2) hs.push(N.pointAt(rt, Math.min(rt.total, along + d)).heading);
    hs.forEach(function (x) { best = Math.min(best, N.angleDiff(h, x)); });
    for (var i = 0; i < hs.length && best > 30; i++) for (var j = i + 1; j < hs.length; j++) {
      if (N.angleDiff(hs[i], h) + N.angleDiff(h, hs[j]) <= N.angleDiff(hs[i], hs[j]) + 1) { best = 0; break; }
    }
    if (best > 30) fail(o.name + ' ' + (along / 1000).toFixed(1) + 'km', '地図の向きがルートと合わない', '向き' + Math.round(h) + '°（この先30mのルートの向きと' + Math.round(best) + '°ずれ）');
  });
});

// ---------- 4. 案内文の一覧との比較 ----------
var text = snapshot.join('\n') + '\n';
var changes = [];
if (process.argv.indexOf('--update') >= 0 || !fs.existsSync(SNAP)) {
  fs.writeFileSync(SNAP, text);
  console.log('snapshot.txt を更新しました（' + snapshot.length + '行）');
} else {
  var old = fs.readFileSync(SNAP, 'utf8').split('\n'), now = text.split('\n');
  var oldSet = {}, nowSet = {};
  old.forEach(function (l) { oldSet[l] = 1; }); now.forEach(function (l) { nowSet[l] = 1; });
  old.forEach(function (l) { if (l && !nowSet[l]) changes.push('  - ' + l); });
  now.forEach(function (l) { if (l && !oldSet[l]) changes.push('  + ' + l); });
}

// ---------- 結果 ----------
console.log('実ルート ' + files.length + '本（曲がり角 ' + routes.reduce(function (a, o) { return a + o.rt.guides.length; }, 0) + 'か所）／総当たり ' + count + '通り／ルール ' + RULES.length + '個');
if (changes.length) {
  console.log('\n案内文が変わりました（意図した変更なら --update で一覧を更新）:');
  console.log(changes.join('\n'));
}
if (problems.length) {
  // 同じルールの総当たりは代表だけ表示
  var shown = {}, out = [];
  problems.forEach(function (p) {
    var key = p.split('\n')[1];
    var k2 = (p.indexOf('総当たり') === 0 ? 'm:' : '') + key.replace(/「.*$/, '');
    if (p.indexOf('総当たり') === 0) { shown[k2] = (shown[k2] || 0) + 1; if (shown[k2] > 3) return; }
    out.push(p);
  });
  console.log('\n問題 ' + problems.length + '件:\n' + out.join('\n'));
  process.exit(1);
}
console.log(changes.length ? '\nルール違反なし（案内文の変更を確認してください）' : '\nすべて合格');
process.exit(changes.length ? 2 : 0);
